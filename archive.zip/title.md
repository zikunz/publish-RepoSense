# CS2103DE Software Engineering iP Code Dashboard

RepoSense is a powerful tool for analyzing repositories. This dashboard provides insights into the Individual Project (iP) codebase, helping instructors and students track development patterns, identify areas for improvement, and monitor code contributions across the course.
